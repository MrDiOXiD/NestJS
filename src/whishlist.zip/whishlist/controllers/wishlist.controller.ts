import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  ParseIntPipe,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOkResponse, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { WishlistService } from '../services/wishlist.service';
import { CurrentUser } from '../../utils/decorators/currentUser.decorator';
import { AuthenticationGuard } from '../../utils/guard/auth.guard';
import { UserEntity } from '@/users/entities/user.entity';

@ApiTags('Wishlist')
@ApiBearerAuth()
@UseGuards(AuthenticationGuard)
@Controller('user/wishlist')
export class WishlistController {
  constructor(private readonly wishlistService: WishlistService) {}

  @Get()
  @ApiOperation({ summary: "List the current user's wishlist" })
  @ApiOkResponse({ description: 'Successfully retrieved wishlist.' })
  async findAll(@CurrentUser() user: UserEntity) {
    return this.wishlistService.findAllForUser(user.id);
  }

  /** Lightweight — just ids, for hydrating heart-icon state on product listing/card grids. */
  @Get('ids')
  @ApiOperation({ summary: "Get just the product ids in the current user's wishlist" })
  @ApiOkResponse({ description: 'Successfully retrieved favorited product ids.' })
  async findAllIds(@CurrentUser() user: UserEntity) {
    return this.wishlistService.findProductIdsForUser(user.id);
  }

  @Post(':productId')
  @ApiOperation({ summary: 'Add a product to the current user\'s wishlist' })
  @ApiParam({ name: 'productId', type: 'integer', example: 1 })
  @ApiOkResponse({ description: 'Added (or already present).' })
  async add(
    @Param('productId', ParseIntPipe) productId: number,
    @CurrentUser() user: UserEntity,
  ) {
    return this.wishlistService.add(user, productId);
  }

  @Delete(':productId')
  @ApiOperation({ summary: 'Remove a product from the current user\'s wishlist' })
  @ApiParam({ name: 'productId', type: 'integer', example: 1 })
  @ApiOkResponse({ description: 'Removed (or already absent).' })
  async remove(
    @Param('productId', ParseIntPipe) productId: number,
    @CurrentUser() user: UserEntity,
  ) {
    await this.wishlistService.remove(user.id, productId);
    return { removed: true };
  }
}
