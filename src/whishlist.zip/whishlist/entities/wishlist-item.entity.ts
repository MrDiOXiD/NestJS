import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
} from 'typeorm';
import { UserEntity } from '@/users/entities/user.entity';
import { ProductEntity } from '@/products/entities/product.entity';

@Entity({ name: 'wishlist_items' })
@Unique(['user', 'product']) // a user can favorite a given product at most once
export class WishlistItemEntity {
  @PrimaryGeneratedColumn()
  id!: number;

  @Index()
  @ManyToOne(() => UserEntity, { onDelete: 'CASCADE' })
  @JoinColumn()
  user!: UserEntity;

  @ManyToOne(() => ProductEntity, { onDelete: 'CASCADE' })
  @JoinColumn()
  product!: ProductEntity;

  @CreateDateColumn()
  createdAt!: Date;
}
