import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { WishlistItemEntity } from '../entities/wishlist-item.entity';
import { UserEntity } from '@/users/entities/user.entity';

@Injectable()
export class WishlistService {
  constructor(
    @InjectRepository(WishlistItemEntity)
    private readonly wishlistRepository: Repository<WishlistItemEntity>,
  ) {}

  async findAllForUser(userId: number): Promise<WishlistItemEntity[]> {
    return this.wishlistRepository.find({
      where: { user: { id: userId } },
      relations: ['product'],
      order: { createdAt: 'DESC' },
    });
  }

  /** Just the product ids — cheap payload for the "is this product favorited" check on product cards. */
  async findProductIdsForUser(userId: number): Promise<number[]> {
    const rows = await this.wishlistRepository.find({
      where: { user: { id: userId } },
      relations: ['product'],
    });
    return rows.map((row) => row.product.id);
  }

  async add(user: UserEntity, productId: number): Promise<WishlistItemEntity> {
    try {
      return await this.wishlistRepository.save(
        this.wishlistRepository.create({
          user,
          product: { id: productId } as any, // reference by id only — never trust/load client product data here
        }),
      );
    } catch (error) {
      // Postgres unique_violation — same product favorited twice
      // (double-click, race condition). Not an error from the user's
      // perspective — the end state they wanted (favorited) is already
      // true, so treat it as success rather than surfacing a 409 for a
      // harmless double-tap on a heart icon.
      if ((error as { code?: string }).code === '23505') {
        const existing = await this.wishlistRepository.findOne({
          where: { user: { id: user.id }, product: { id: productId } },
        });
        if (existing) return existing;
      }
      throw error;
    }
  }

  async remove(userId: number, productId: number): Promise<void> {
    const result = await this.wishlistRepository.delete({
      user: { id: userId },
      product: { id: productId },
    });
    // Removing something already absent is a no-op success, not a 404
    // — same idempotency reasoning as add() above.
    void result;
  }
}
